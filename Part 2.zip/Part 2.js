import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();



export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Genre" component={GenreScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Button title="Enter Book" onPress={() => navigation.navigate('Genre')} />
      <Text style={styles.heading}>Welcome Back</Text>
      <Text style={styles.name}>Monde Mkhize</Text>
    </View>
  );
}

function Genrepage({ navigation }) {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [genre, setGenre] = useState('');
  const [numberofpages, setNumberofpages] = useState('');
  const [bookInfo, setBookInfo] = useState({ Title: '', Author: '', Genre: '', Numberofpages: '' });

  useEffect(() => {
    loadBookInfo();
  }, []);

  async function loadBookInfo() {
    try {
      const storedBookInfo = await AsyncStorage.getItem('BOOK_INFO');

      if (storedBookInfo) {
        setBookInfo(JSON.parse(storedBookInfo));
      }
    } catch (e) {
      console.error('Failed to load book info.');
    }
  }

  async function saveBookInfo() {
    const bookData = {
      Title: title,
      Author: author,
      Genre: genre,
      Numberofpages: numberofpages,
    };
    try {
      await AsyncStorage.setItem('BOOK_INFO', JSON.stringify(bookData));
      setBookInfo(bookData);
    } catch (e) {
      console.error('Failed to save book info.');
    }
  }

  return (
    <View style={styles.containerGenre}>
      <Button title="Homepage" onPress={() => navigation.navigate('Home')} />
      <Text style={styles.enterbook}>Enter your latest Book</Text>
      <TextInput
        style={styles.TitleEntry}
        placeholder="Title"
        onChangeText={(newText) => setTitle(newText)}
      />
      <TextInput
        style={styles.TitleEntry}
        placeholder="Author"
        onChangeText={(newText) => setAuthor(newText)}
      />
      <TextInput
        style={styles.TitleEntry}
        placeholder="Genre"
        onChangeText={(newText) => setGenre(newText)}
      />
      <TextInput
        style={styles.TitleEntry}
        placeholder="Number of pages"
        onChangeText={(newText) => setNumberofpages(newText)}
      />
      <Button title="Save Book Info" onPress={saveBookInfo} />
      <Text style={styles.bookInfoText}>Book Info:</Text>
      <Text>Title: {bookInfo.Title}</Text>
      <Text>Author: {bookInfo.Author}</Text>
      <Text>Genre: {bookInfo.Genre}</Text>
      <Text>Number of Pages: {bookInfo.Numberofpages}</Text>
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    // Your container styles...
  },
  // Your other styles...
  bookInfoText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
  },
});

